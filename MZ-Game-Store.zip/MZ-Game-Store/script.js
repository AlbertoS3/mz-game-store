const products=[
{id:1,name:"Pack FC Mobile",cat:"FC Mobile",price:500,emoji:"⚽",desc:"Pack digital para conteúdo gamer autorizado."},
{id:2,name:"Gift Card Gamer",cat:"Gift Cards",price:1000,emoji:"🎁",desc:"Código digital. O valor varia conforme o cartão."},
{id:3,name:"Pack Recursos",cat:"Recursos",price:750,emoji:"🪙",desc:"Pacote de recursos digitais para jogos compatíveis."},
{id:4,name:"Skin Pack",cat:"Digital",price:650,emoji:"🧩",desc:"Pacote visual para uso onde for permitido."},
{id:5,name:"Coins Pack",cat:"Recursos",price:1200,emoji:"💰",desc:"Recurso digital para jogos que permitam a compra."},
{id:6,name:"Starter Gamer",cat:"Digital",price:900,emoji:"🎮",desc:"Kit digital para começar sua experiência gamer."},
{id:7,name:"FC Mobile Pack Pro",cat:"FC Mobile",price:1500,emoji:"🏆",desc:"Pacote premium de recursos autorizados."},
{id:8,name:"Gift Card Digital",cat:"Gift Cards",price:2000,emoji:"💳",desc:"Cartão digital sujeito à região e disponibilidade."}
];
let cart=JSON.parse(localStorage.getItem("mz_cart")||"[]");
let currentCat="Todos";
const $=s=>document.querySelector(s);
function money(v){return v.toLocaleString("pt-MZ")+" MT"}
function save(){localStorage.setItem("mz_cart",JSON.stringify(cart));renderCart();$("#cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0)}
function renderProducts(){
 const q=$("#searchInput").value.toLowerCase();
 const list=products.filter(p=>(currentCat==="Todos"||p.cat===currentCat)&&(`${p.name} ${p.desc}`.toLowerCase().includes(q)));
 $("#productGrid").innerHTML=list.map(p=>`<article class="product"><div class="product-img">${p.emoji}</div><div class="product-info"><span class="tag">${p.cat.toUpperCase()}</span><h3>${p.name}</h3><p>${p.desc}</p><span class="price">${money(p.price)}</span><button class="add" onclick="add(${p.id})">Adicionar</button></div></article>`).join("")||"<p>Nenhum produto encontrado.</p>";
}
function add(id){const p=products.find(x=>x.id===id), item=cart.find(x=>x.id===id); item?item.qty++:cart.push({...p,qty:1});save();toast("Produto adicionado ao carrinho.")}
function renderCart(){
 $("#cartItems").innerHTML=cart.length?cart.map(x=>`<div class="cart-item"><div class="emoji">${x.emoji}</div><div><h4>${x.name}</h4><small>${money(x.price)} cada</small></div><div class="qty"><button onclick="change(${x.id},-1)">−</button><b>${x.qty}</b><button onclick="change(${x.id},1)">+</button></div></div>`).join(""):"<p class='muted'>Seu carrinho está vazio.</p>";
 $("#cartTotal").textContent=money(cart.reduce((a,x)=>a+x.price*x.qty,0));
}
function change(id,d){const x=cart.find(i=>i.id===id);if(!x)return;x.qty+=d;if(x.qty<=0)cart=cart.filter(i=>i.id!==id);save()}
function openCart(){$("#cartDrawer").classList.add("open");$("#overlay").classList.add("open")}
function closeCart(){$("#cartDrawer").classList.remove("open");$("#overlay").classList.remove("open")}
function toast(t){const e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2200)}
document.querySelectorAll(".category").forEach(b=>b.onclick=()=>{document.querySelectorAll(".category").forEach(x=>x.classList.remove("active"));b.classList.add("active");currentCat=b.dataset.cat;renderProducts()});
$("#searchInput").oninput=renderProducts;
$("#cartBtn").onclick=openCart;$("#closeCart").onclick=closeCart;$("#overlay").onclick=closeCart;
$("#checkoutBtn").onclick=()=>{if(!cart.length)return toast("Adicione produtos primeiro.");$("#checkoutModal").classList.add("open");closeCart()};
$("#closeModal").onclick=()=>$("#checkoutModal").classList.remove("open");
$("#checkoutForm").onsubmit=e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));const order={id:"MZ-"+Date.now().toString().slice(-6),date:new Date().toLocaleString("pt-MZ"),...data,items:cart,total:cart.reduce((a,x)=>a+x.price*x.qty,0)};const orders=JSON.parse(localStorage.getItem("mz_orders")||"[]");orders.unshift(order);localStorage.setItem("mz_orders",JSON.stringify(orders));cart=[];save();e.target.reset();$("#checkoutModal").classList.remove("open");renderOrders();toast("Pedido criado com sucesso!")};
function renderOrders(){const o=JSON.parse(localStorage.getItem("mz_orders")||"[]");$("#ordersBox").innerHTML=o.length?o.map(x=>`<div class="order"><strong>${x.id}</strong> · ${x.date}<br><small>${x.name} · ${x.payment} · Total: ${money(x.total)}</small></div>`).join(""):"Ainda não existem pedidos neste dispositivo."}
$("#searchBtn").onclick=()=>{document.querySelector("#products").scrollIntoView();$("#searchInput").focus()};
$("#menuBtn").onclick=()=>{const n=$("#nav");n.style.display=n.style.display==="flex"?"":"flex"};
renderProducts();save();renderOrders();
